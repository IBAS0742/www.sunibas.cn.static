function ElementListToArray(el) {
    let list = [];
    for (let i = 0;i < el.length;i++) list.push(el[i]);
    return list;
}
function getRealData() {
    let sellData = {};
    let buyData = {};
    let sellList = ElementListToArray(document.querySelector(`#app > div > div.trade-panel-box > div.react-grid-layout.layout-xl-box > div:nth-child(2) > div.market-box > div > div:nth-child(2) > div > div > div.order-book-body > div.book-body-wrap > ul.order-book-list.asks`).getElementsByTagName('li'));
    let buyList = ElementListToArray(document.querySelector(`#app > div > div.trade-panel-box > div.react-grid-layout.layout-xl-box > div:nth-child(2) > div.market-box > div > div:nth-child(2) > div > div > div.order-book-body > div.book-body-wrap > ul.order-book-list.bids`).getElementsByTagName('li'));
    sellList.forEach(sl => {
        let span = sl.getElementsByTagName('span');
        let p = +span[0].innerText.replace(/,/,'');
        if (!(p in sellData)) sellData[p] = 0;
        sellData[p] += + span[1].innerText;
    });
    buyList.forEach(sl => {
        let span = sl.getElementsByTagName('span');
        let p = +span[0].innerText.replace(/,/,'');
        if (!(p in buyData)) buyData[p] = 0;
        buyData[p] += + span[1].innerText;
    });
    return {
        sellData,buyData
    }
}

//
function toOption() {
    let option = {
        xAxis: {
            type: 'category',
            data: []
        },
        yAxis: {
            type: 'value'
        },
        series: [{
            data: [],
            type: 'line',
            smooth: true,
            connectNulls: true
        },{
            data: [],
            type: 'line',
            smooth: true,
            connectNulls: true
        }]
    };
    let ds = [];
    for (let i in datas.buy) {
        ds.push({
            price: i,
            num: datas.buy[i],
            type: 'buy'
        });
    }
    for (let i in datas.sell) {
        ds.push({
            price: i,
            num: datas.sell[i],
            type: 'sell'
        });
    }
    ds.sort((a,b) => a.price - b.price).forEach(_ => {
        option.xAxis.data.push(_.price);
        if (_.type === 'buy') {
            option.series[0].data.push(_.num);
            option.series[1].data.push(null);
        } else {
            option.series[0].data.push(null);
            option.series[1].data.push(_.num);
        }
    });
    console.log(JSON.stringify(option,'','\t'));
}

var datas = {
    sell: {},
    buy: {},
    times: 0
};
var id = setInterval(() => {
    let obj = getRealData();
    for (let i in obj.sellData) {
        if (i in datas.sell) {
            datas.sell[i] += obj.sellData[i];
        } else {
            datas.sell[i] = obj.sellData[i];
        }
    }
    for (let i in obj.buyData) {
        if (i in datas.buy) {
            datas.buy[i] += obj.buyData[i];
        } else {
            datas.buy[i] = obj.buyData[i];
        }
    }
    if (datas.times > 10) {
        console.log('over');
        clearInterval(id);
    }
    datas.times++;
},1000);