window.menu = {
    "status": 0,
    "msg": "ok",
    "data": [
        {
            "name": "LAADS Data 文件下载",
            "url": "./pages/LADDS_Data.html"
        },
        {
            "name": "GES DISC 文件下载",
            "url": "./pages/GES_DISC.html"
        },
        {
            "name": "GdalWarp 裁剪",
            "url": "./pages/GDALwarp_clip.html"
        }
    ].map((_,ind) => {
        _.id = ind;_.icon = "";
        return _;
    })
};