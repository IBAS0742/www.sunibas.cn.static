window.menu = {
    "status": 0,
    "msg": "ok",
    "data": [
        {
            "name": "LAADS Data 文件下载",
            "url": "./pages/LADDS_Data.html"
        },
        {
            "name": "GES DISC 文件下载",
            "url": "./pages/GES_DISC.html"
        },
        {
            "name": "GdalWarp 裁剪",
            "url": "./pages/GDALwarp_clip.html"
        },
        {
            "name": "GDAL_MERGE",
            "url": "./pages/GDALmerge.html"
        },
        {
            "name": "ffmpeg 工具",
            "url": "./pages/ffmpeg.html"
        },
        {
            "name": "表单编辑",
            "url": "./pages/表单制作.html"
        },
        {
            "name": "orginfo",
            "url": "./pages/orginfo.html"
        }
    ].map((_,ind) => {
        _.id = ind;_.icon = "";
        return _;
    })
};